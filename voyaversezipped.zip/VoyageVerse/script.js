// Sample destination data (would be replaced with Firebase data)
const destinations = [
    {
        id: 1,
        name: 'Santorini, Greece',
        description: 'Iconic white-washed buildings perched on cliffs',
        image: 'https://img.imageboss.me/greca/width/3840/format:webp/5a214aaa378d8.jpeg',
        reviews: 124,
        rating: 4.8
    },
    {
        id: 2,
        name: 'Kyoto, Japan',
        description: 'Ancient temples amid beautiful cherry blossoms',
        image: 'https://content.r9cdn.net/rimg/dimg/10/dd/c1632a46-city-20339-15873436110.jpg?width=1200&height=630&xhint=792&yhint=1072&crop=true',
        reviews: 98,
        rating: 4.9
    }
];

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    displayDestinations();
    initializeTabs();
    initializeAuth();
    initializeWishlist();
});

// Display destinations in the grid
function displayDestinations() {
    const container = document.getElementById('destinations-container');
    container.innerHTML = destinations.map(destination => `
        <div class="destination-card">
            <img src="${destination.image}" alt="${destination.name}" class="destination-image">
            <div class="destination-info">
                <div class="destination-header">
                    <h3 class="destination-title">${destination.name}</h3>
                    <button class="wishlist-btn" data-id="${destination.id}">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
                <p class="destination-description">${destination.description}</p>
                <div class="destination-meta">
                    <span><i class="fas fa-star"></i> ${destination.rating}</span>
                    <span><i class="fas fa-comment"></i> ${destination.reviews} reviews</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Tab functionality
function initializeTabs() {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            // In a real app, this would filter content based on selected tab
        });
    });
}

// Authentication modal functionality
function initializeAuth() {
    const modal = document.getElementById('authModal');
    const signInBtn = document.getElementById('signInBtn');
    const signUpBtn = document.getElementById('signUpBtn');
    const closeBtn = document.querySelector('.close');
    const authTitle = document.getElementById('authTitle');
    const authForm = document.getElementById('authForm');

    signInBtn.onclick = () => {
        authTitle.textContent = 'Sign In';
        modal.style.display = 'block';
    };

    signUpBtn.onclick = () => {
        authTitle.textContent = 'Sign Up';
        modal.style.display = 'block';
    };

    closeBtn.onclick = () => {
        modal.style.display = 'none';
    };

    window.onclick = (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };

    authForm.onsubmit = (e) => {
        e.preventDefault();
        // In a real app, this would handle Firebase authentication
        console.log('Authentication submitted');
        modal.style.display = 'none';
    };
}

// Wishlist functionality
function initializeWishlist() {
    const wishlistButtons = document.querySelectorAll('.wishlist-btn');
    wishlistButtons.forEach(button => {
        button.addEventListener('click', () => {
            // In a real app, this would sync with Firebase
            button.classList.toggle('active');
        });
    });
}

// Search functionality
const searchInput = document.getElementById('search-input');
searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filteredDestinations = destinations.filter(dest => 
        dest.name.toLowerCase().includes(searchTerm) || 
        dest.description.toLowerCase().includes(searchTerm)
    );
    // In a real app, this would update the displayed destinations
});